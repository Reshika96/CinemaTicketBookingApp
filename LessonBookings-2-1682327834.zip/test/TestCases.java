


import java.util.List;
import lessonbookings.ActivityLessons;
import lessonbookings.AllReviews;
import lessonbookings.Bookings;
import lessonbookings.PreRegisteredCustomers;
import lessonbookings.ProgramMainClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestCases {
    

    @Test
    public void sufficientNumberOfLessons() {
        List<ActivityLessons> activityLessons = ActivityLessons.activityLessons();
        assertTrue(activityLessons.size()==32);
    }
    
    
    
    @Test
    public void isAbleToBookLesson() {
        String customerCode = "Jim258";
        String lesson = "Box Fit Title 1";
        String bookingConfirmedAt = String.valueOf(java.time.LocalDate.now());
        
        String weekday = "";
        String activity = "";
        double cost = 0.0;
        int bookingId = ProgramMainClass.findRandomBookingId();
        List<ActivityLessons> activityLessons = ActivityLessons.activityLessons();
        for(int i=0; i<activityLessons.size(); i++){
            if(activityLessons.get(i).getLesson().equalsIgnoreCase(lesson)){
                weekday = activityLessons.get(i).getWeekendDay();
                activity = activityLessons.get(i).getActivity();
                cost = activityLessons.get(i).getCost();
            }
        }        
        Bookings book = new Bookings(bookingId,activity,lesson,bookingConfirmedAt,customerCode,Bookings.BOOKED,cost);
        Bookings.totalBookings.add(book);
        List<Bookings> bookings = Bookings.getBookings();
        assertTrue(bookings.size()>=1);
    }
    
    
    
    
    @Test
    public void isAbleToAttendLesson() {
        String customerCode = "Jim258";
        String lesson = "Zumba Title 2";
        String bookingConfirmedAt = String.valueOf(java.time.LocalDate.now());
        String activity = "";
        double cost = 0.0;
        int bookingId = 841523;
        List<ActivityLessons> activityLessons = ActivityLessons.activityLessons();
        for(int i=0; i<activityLessons.size(); i++){
            if(activityLessons.get(i).getLesson().equalsIgnoreCase(lesson)){
                activity = activityLessons.get(i).getActivity();
                cost = activityLessons.get(i).getCost();
            }
        }        
        Bookings book = new Bookings(bookingId,activity,lesson,bookingConfirmedAt,customerCode,Bookings.BOOKED,cost);
        Bookings.totalBookings.add(book);
        
        //Attend Class
        String classExperiences = "Great Experience!";
        int getRatingNumber = 4;
        AllReviews obj = new AllReviews(activity,lesson,classExperiences,getRatingNumber,customerCode);
        AllReviews.totalReviews.add(obj);
        List<AllReviews> allReviews = AllReviews.getReviews();
        //Update status
        List<Bookings> bookings = Bookings.getBookings();
        for(int i=0; i<bookings.size(); i++){
            if(bookings.get(i).getBookingID() == bookingId){
               bookings.get(i).setBookingStatus(Bookings.ATTENDED);
            }
        }
        assertTrue(allReviews.size()>=1);
    }
    
    
    @Test
    public void isStatusChangedToAttended() {
        int bookingId = 841523;
        List<Bookings> bookings = Bookings.getBookings();
        for(int i=0; i<bookings.size(); i++){
            if(bookings.get(i).getBookingID() == bookingId){
               assertTrue(bookings.get(i).getBookingStatus().equalsIgnoreCase(Bookings.ATTENDED));
            }
        }
    }
    
    
    @Test
    public void cancelFunctionality() {
        int bookingId = 841523;
        List<Bookings> bookings = Bookings.getBookings();
        for(int i=0; i<bookings.size(); i++){
            if(bookings.get(i).getBookingID() == bookingId){
               bookings.get(i).setBookingStatus(Bookings.CANCELLED);
            }
        }
        
        for(int i=0; i<bookings.size(); i++){
            if(bookings.get(i).getBookingID() == bookingId){
               assertTrue(bookings.get(i).getBookingStatus().equalsIgnoreCase(Bookings.CANCELLED));
            }
        }
    }
    
    
    @Test
    public void isCustomerCodeValid() {
        String customerCode = "Jim258";
        boolean isValid = false;
        List<PreRegisteredCustomers> pre_registererd_customers = PreRegisteredCustomers.getRegisteredCustomers();
        for(int i=0; i<pre_registererd_customers.size(); i++){
            if(pre_registererd_customers.get(i).getCustomerCode().equalsIgnoreCase(customerCode)){
                isValid  = true;
            }
        }
        
        if(isValid){
            System.out.println("Success Message - Customer Code is Valid");
        }else{
            System.out.println("Error Message - Customer Code is Not Valid");
        }
    }
    
}
