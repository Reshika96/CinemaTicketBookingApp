
package lessonbookings;

import java.util.ArrayList;
import java.util.List;


public class PreRegisteredCustomers {
    
    private String customerCode;
    private String fullName;
    private int age;
    private String gender;

    
    public static ArrayList <PreRegisteredCustomers> registeredCust = new ArrayList<>();

        
    public PreRegisteredCustomers(String customerCode, String fullName, int age, String gender) {
        this.customerCode = customerCode;
        this.fullName = fullName;
        this.age = age;
        this.gender = gender;
    }

    
    
    public String getCustomerCode() {
        return customerCode;
    }

    public String getFullName() {
        return fullName;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }
    
    
    public static  List<PreRegisteredCustomers> getRegisteredCustomers(){
        PreRegisteredCustomers p1 = new PreRegisteredCustomers("Hunter480","Hunter",35,"Male");
        PreRegisteredCustomers p2 = new PreRegisteredCustomers("Robinson470","Robinson",30,"Male");
        PreRegisteredCustomers p3 = new PreRegisteredCustomers("Smith450","Smith",40,"Male");
        PreRegisteredCustomers p4 = new PreRegisteredCustomers("Brandon256","Brandon",32,"Male");
        PreRegisteredCustomers p5 = new PreRegisteredCustomers("Palmer563","Palmer",38,"Male");
        PreRegisteredCustomers p6 = new PreRegisteredCustomers("Jim258","Jim",29,"Male");
        PreRegisteredCustomers p7 = new PreRegisteredCustomers("Shaw467","Shaw",36,"Male");
        PreRegisteredCustomers p8 = new PreRegisteredCustomers("Greg145","Greg",39,"Male");
        
        PreRegisteredCustomers.registeredCust.add(p1);
        PreRegisteredCustomers.registeredCust.add(p2);
        PreRegisteredCustomers.registeredCust.add(p3);
        PreRegisteredCustomers.registeredCust.add(p4);
        PreRegisteredCustomers.registeredCust.add(p5);
        PreRegisteredCustomers.registeredCust.add(p6);
        PreRegisteredCustomers.registeredCust.add(p7);
        PreRegisteredCustomers.registeredCust.add(p8);
        return registeredCust;
    }
    
}
