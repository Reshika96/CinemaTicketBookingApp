
package lessonbookings;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;


public class ProgramMainClass {
    
    public static FileWriter fileWriter = null;
    public static BufferedWriter bufferedWriter = null;
    public static PrintWriter printWriter = null;
    
     
    public static void main(String[] args) throws IOException {
        int choice;
        do {
            choice = bookingMenu();
            switch (choice) {
                case 1:
                    timetable();
                    break;
                case 2:
                    bookings("",0);
                    break;
                case 3:
                    cancel();
                    break;
                case 4:
                    change();
                    break;
                case 5:
                    classReview();
                    break;
                case 6:
                    getIncReport();
                    break;
                case 7:
                    getAvgRatingReport();
                    break;
                case 8:
                    System.out.println("\nExiting program...\n");
                    break;
                default:
                    System.out.println("\nPlease enter a valid choice (1-8)");
                    break;
            }
        } while (choice != 8);
    }
    
    
    private static void timetable(){
        displayTimetable("","");
    }
    
    private static int displayAvailableSeats(String lesson){
        List<Bookings> totalBookings = Bookings.getBookings();
        int totalAvailableSeats = 0;
        
        for(int i=0; i<totalBookings.size(); i++){
            if(totalBookings.get(i).getLesson().equalsIgnoreCase(lesson)){
                totalAvailableSeats += 1;
            }
        }
        return totalAvailableSeats;
    }
      
      
    private static void displayTimetable(String activity, String day){
        List<ActivityLessons> activityLessons = ActivityLessons.activityLessons();
        System.out.println("==================================================================================================");
        for(int i=0; i<activityLessons.size(); i++){
            int bookedSeats = displayAvailableSeats(activityLessons.get(i).getLesson());
            int availableSeats = activityLessons.get(i).getSeats() - bookedSeats;
            if(activityLessons.get(i).getActivity().equalsIgnoreCase(activity)){
                System.out.println("\t\t\t\tActivity : "+activityLessons.get(i).getActivity());
                System.out.println("\t\t\t\tLesson : "+activityLessons.get(i).getLesson());
                System.out.println("\t\t\t\tCost : $"+activityLessons.get(i).getCost());
                System.out.println("\t\t\t\tClass On : "+activityLessons.get(i).getLessonDate());
                System.out.println("\t\t\t\tClass Timings : "+activityLessons.get(i).getLessonAt());
                System.out.println("\t\t\t\tWeek Day : "+activityLessons.get(i).getWeekendDay());
                System.out.println("\t\t\t\tAvailability : "+activityLessons.get(i).getAvailable()+" with "+availableSeats+" seats");
                System.out.println("=================================================================================================="); 
            }else if(activityLessons.get(i).getWeekendDay().equalsIgnoreCase(day)){
                System.out.println("\t\t\t\tActivity : "+activityLessons.get(i).getActivity());
                System.out.println("\t\t\t\tLesson : "+activityLessons.get(i).getLesson());
                System.out.println("\t\t\t\tCost : $"+activityLessons.get(i).getCost());
                System.out.println("\t\t\t\tClass On : "+activityLessons.get(i).getLessonDate());
                System.out.println("\t\t\t\tClass Timings : "+activityLessons.get(i).getLessonAt());
                System.out.println("\t\t\t\tWeek Day : "+activityLessons.get(i).getWeekendDay());
                System.out.println("\t\t\t\tAvailability : "+activityLessons.get(i).getAvailable()+" with "+availableSeats+" seats");
                System.out.println("==================================================================================================");
            }else if(activity.equalsIgnoreCase("") && day.equalsIgnoreCase("")){
                System.out.println("\t\t\t\tActivity : "+activityLessons.get(i).getActivity());
                System.out.println("\t\t\t\tLesson : "+activityLessons.get(i).getLesson());
                System.out.println("\t\t\t\tCost : $"+activityLessons.get(i).getCost());
                System.out.println("\t\t\t\tClass On : "+activityLessons.get(i).getLessonDate());
                System.out.println("\t\t\t\tClass Timings : "+activityLessons.get(i).getLessonAt());
                System.out.println("\t\t\t\tWeek Day : "+activityLessons.get(i).getWeekendDay());
                System.out.println("\t\t\t\tAvailability : "+activityLessons.get(i).getAvailable()+" with "+availableSeats+" seats");
                System.out.println("==================================================================================================");
            }
        }

        if(activity.equalsIgnoreCase("") && day.equalsIgnoreCase("")){
            System.out.print("\nEnter 'Y' to apply filter on timetable : ");
            Scanner sc = new Scanner(System.in);
            String applyFilter =sc.nextLine();

            if(applyFilter.equalsIgnoreCase("Y") || applyFilter.equalsIgnoreCase("Yes")){
                applyFilter();
            } else{
                book();
            }
        }else{
            System.out.print("\nEnter 'Y' to book any of the above lessons : ");
            Scanner sc = new Scanner(System.in);
            String bookLesson =sc.nextLine();

            if(bookLesson.equalsIgnoreCase("Y") || bookLesson.equalsIgnoreCase("Yes")){
                book();
            } 
        }
    }

    
    private static void book(){
        System.out.println("\n------------------ Booking Process ------------------\n");
        Scanner sc =  new Scanner(System.in);
        System.out.print("\nEnter Your Valid Customer Code : ");
        String customerCode = sc.nextLine();
        
        boolean customerExists = isCustomerCodeExist(customerCode);
        if(!customerExists){
            System.out.println("\nCustomer Code does not exists in the system");
            return;
        }
        
        List<ActivityLessons> activityLessons = ActivityLessons.activityLessons();
        System.out.println("\n-------------- Available Lessons as below -------------- \n");
        for(int i=0; i<activityLessons.size(); i++){
            System.out.println(activityLessons.get(i).getLesson());
        }
        
        
        System.out.print("\nEnter any of the above lesson : ");
        String lesson = sc.nextLine();
        boolean selectedLessonExists = selectedLessonExists(lesson);
        if(!selectedLessonExists){
            System.out.println("\nGiven lesson does not exist in the system");
            return;
        }
        
        //Is twice checking
        boolean isTwiceChecking = isTwiceChecking(lesson,customerCode);
        if(isTwiceChecking){
            System.out.println("\nAlready booked given lesson");
            return;
        }
        
        //is no seat available
        int bookedSeats = displayAvailableSeats(lesson);
        int availableSeats = Bookings.TOTAL_SEATS - bookedSeats;
        if(availableSeats == 0){
            System.out.println("\nNo seat is available for this lesson.");
            return;
        }
            
        
        //Get lesson details
        String weekday = "";
        String activity = "";
        double cost = 0.0;
        int bookingId = findRandomBookingId();
        String bookingConfirmedAt = String.valueOf(java.time.LocalDate.now());
        for(int i=0; i<activityLessons.size(); i++){
            if(activityLessons.get(i).getLesson().equalsIgnoreCase(lesson)){
                weekday = activityLessons.get(i).getWeekendDay();
                activity = activityLessons.get(i).getActivity();
                cost = activityLessons.get(i).getCost();
            }
        }
        
        Bookings book = new Bookings(bookingId,activity,lesson,bookingConfirmedAt,customerCode,Bookings.BOOKED,cost);
        Bookings.totalBookings.add(book);
        
        //Update available seats
        for(int i=0; i<activityLessons.size(); i++){
            if(activityLessons.get(i).getLesson().equalsIgnoreCase(lesson)){
                activityLessons.get(i).setSeats(activityLessons.get(i).getSeats());
            }
        }
        System.out.println("\nYour Booking is Confirmed with the system");
        System.out.println("\nYour Generated Booking ID is "+bookingId+"\n");
    }
    
    
    public static int findRandomBookingId(){
        Random random = new Random();
        int number = random.nextInt(900000 - 800000) + 800000;
        return number;
    }
    
    private static boolean isCustomerCodeExist(String customerCode){
        boolean isCodeExist = false;
        List<PreRegisteredCustomers> registeredCustomers = PreRegisteredCustomers.getRegisteredCustomers();
        for(int i=0; i<registeredCustomers.size(); i++){
            if(registeredCustomers.get(i).getCustomerCode().equalsIgnoreCase(customerCode)){
                isCodeExist = true;
            }
        }
        return isCodeExist;
    }
    
    private static boolean selectedLessonExists(String lesson){
        boolean isLessonExist = false;
        List<ActivityLessons> activityLessons = ActivityLessons.activityLessons();
        for(int i=0; i<activityLessons.size(); i++){
            if(activityLessons.get(i).getLesson().equalsIgnoreCase(lesson)){
                isLessonExist = true;
            }
        }
        return isLessonExist;
    }
    
    
    private static boolean isTwiceChecking(String lesson, String customerCode){
        boolean isFind = false;
        List<Bookings> bookings = Bookings.getBookings();
        for(int i=0; i<bookings.size(); i++){
            if(bookings.get(i).getLesson().equalsIgnoreCase(lesson) && bookings.get(i).getBookedBy().equalsIgnoreCase(customerCode)
                    && (bookings.get(i).getBookingStatus().equalsIgnoreCase(Bookings.BOOKED) || bookings.get(i).getBookingStatus().equalsIgnoreCase(Bookings.CHANGED))){
                isFind = true;
            }
        }
        return isFind;
    }

    private static void applyFilter(){
        Scanner sc = new Scanner(System.in);

        System.out.println("\nSelect Option.  : ");
        System.out.println("1. Apply Filter On Activity");
        System.out.println("2. Apply Filter On Weekend Days");
        System.out.print("\nPlease Enter your choice : ");

        String getOption = sc.nextLine();
        while (getOption.equals("") || !checkSelectOptionValidOrNot(getOption))
        {
            System.out.print("\nYou must enter a numerical menu option - ");
            getOption = sc.nextLine();
        }
        
        int givenChoice = Integer.parseInt(getOption);
        
        switch (givenChoice)
        {
            case 1 -> filterOnActivity();
            case 2 -> filterOnDays();
            default -> System.out.println("\nPlease Enter Valid Option");
        }
    }
    
    /*
    * Get Timetable based on activity
    */
    private static void filterOnActivity(){
        Scanner userChoice = new Scanner(System.in);

        System.out.println("\nSelect Activity  : ");
        System.out.println("1. Box Fit");
        System.out.println("2. Zumba");
        System.out.println("3. Spin");
        System.out.println("4. Bodysculpt");
        System.out.print("\nEnter an Option : ");

        String takeInput = userChoice.nextLine();
        while (takeInput.equals("") || !checkSelectOptionValidOrNot(takeInput))
        {
            System.out.print("\nYou must enter a numerical menu option : ");
            takeInput = userChoice.nextLine();
        }
        
        int givenChoice = Integer.parseInt(takeInput);
        
        String fitnessType = "";
        switch (givenChoice) {
            case 1 -> {
                fitnessType = "Box Fit";
                displayTimetable(fitnessType,"");
           }
            case 2 -> {
                fitnessType = "Zumba";
                displayTimetable(fitnessType,"");
           }
            case 3 -> {
                fitnessType = "Spin";
                displayTimetable(fitnessType,"");
           }
            case 4 -> {
                fitnessType = "Bodysculpt";
                displayTimetable(fitnessType,"");
           }
            default -> System.out.println("\nPlease Enter Valid Option");
        }
    }
    
    /*
    * Get timetable based on days
    */
    private static void filterOnDays(){
        Scanner userChoice = new Scanner(System.in);

        System.out.println("\nSelect Day  : ");
        System.out.println("1. Sat");
        System.out.println("2. Sun");
        System.out.print("\nEnter an Option : ");

        String takeInput = userChoice.nextLine();
        while (takeInput.equals("") || !checkSelectOptionValidOrNot(takeInput))
        {
            System.out.print("\nYou must enter a numerical menu option : ");
            takeInput = userChoice.nextLine();
        }
        
        int givenChoice = Integer.parseInt(takeInput);
        
        String day = "";
        switch (givenChoice) {
            case 1 -> {
                day = "sat";
                displayTimetable("",day);
           }
            case 2 -> {
                day = "sun";
                displayTimetable("",day);
           }
            default -> System.out.println("\nPlease Enter Valid Option");
        }
    }
    
    private static int bookingMenu(){     
        Scanner sc = new Scanner(System.in);

        System.out.println("\nSelect Option : ");
        System.out.println("1. View Timetable");
        System.out.println("2. View Bookings");
        System.out.println("3. Cancel Class");
        System.out.println("4. Change Class");
        System.out.println("5. Add a class review ");
        System.out.println("6. Get the Income Report produced for each activity");
        System.out.println("7. Download the Customer Totals Report for Each Course together with the Average Rating Report.");
        System.out.println("8. Exit Program");
        System.out.print("\nEnter an option : ");

        String getOption = sc.nextLine();
        while (getOption.equals("") || !checkSelectOptionValidOrNot(getOption))
        {
            System.out.print("\nYou must enter a numerical menu option - ");
            getOption = sc.nextLine();
        }
        return Integer.parseInt(getOption);
    }
    
    
    private static boolean checkSelectOptionValidOrNot(String given_option)
    {
        if (given_option == null || given_option.isEmpty()) {
             return false;
         }
         for (int i = 0; i < given_option.length(); i++) {
             if (!Character.isDigit(given_option.charAt(i))) {
                 return false;
             }
         }
         return true;
    }
    
    
    private static void bookings(String customerCode, int bookingsId){
        List<Bookings> bookings = Bookings.getBookings();
        
        if(bookings.size() == 0){
            System.out.println("\nNo Booking Record Exists");
            return;
        }
        
        List<ActivityLessons> activityLesson = ActivityLessons.activityLessons();
        int counter = 1;
        System.out.println("==================================================================================================");
        for(int i=0; i<bookings.size(); i++){
            if(!customerCode.equalsIgnoreCase("") && bookings.get(i).getBookedBy().equalsIgnoreCase(customerCode)){
                System.out.println("\nBookings Detail "+counter+" :- \n");
                System.out.println("\t\t\t\tBooking ID : "+bookings.get(i).getBookingID());
                System.out.println("\t\t\t\tActivity : "+bookings.get(i).getActivity());
                System.out.println("\t\t\t\tLesson : "+bookings.get(i).getLesson());
                System.out.println("\t\t\t\tCost : $"+bookings.get(i).getCost());
                System.out.println("\t\t\t\tBooked On : "+bookings.get(i).getBookingConfirmedAt());
                System.out.println("\t\t\t\tBooked By : "+bookings.get(i).getBookedBy());
                System.out.println("\t\t\t\tBooking Status : "+bookings.get(i).getBookingStatus());

                System.out.println("\nLesosn Detail :- \n");

                for(int j=0; j<activityLesson.size(); j++){
                    if(activityLesson.get(j).getLesson().equalsIgnoreCase(bookings.get(i).getLesson())){
                        System.out.println("\t\t\t\tClass On : "+activityLesson.get(j).getLessonDate());
                        System.out.println("\t\t\t\tClass Timings : "+activityLesson.get(j).getLessonAt());
                        System.out.println("\t\t\t\tClass Day : "+activityLesson.get(j).getWeekendDay());
                        System.out.println("\t\t\t\tClass Date : "+activityLesson.get(j).getLessonDate());
                    }
                }
                System.out.println("==================================================================================================");
                counter += 1;
            }else if(bookingsId != 0 && bookings.get(i).getBookingID() == bookingsId){
                System.out.println("\nBookings Detail "+counter+" :- \n");
                System.out.println("\t\t\t\tBooking ID : "+bookings.get(i).getBookingID());
                System.out.println("\t\t\t\tActivity : "+bookings.get(i).getActivity());
                System.out.println("\t\t\t\tLesson : "+bookings.get(i).getLesson());
                System.out.println("\t\t\t\tCost : $"+bookings.get(i).getCost());
                System.out.println("\t\t\t\tBooked On : "+bookings.get(i).getBookingConfirmedAt());
                System.out.println("\t\t\t\tBooked By : "+bookings.get(i).getBookedBy());
                System.out.println("\t\t\t\tBooking Status : "+bookings.get(i).getBookingStatus());

                System.out.println("\nLesosn Detail :- \n");

                for(int j=0; j<activityLesson.size(); j++){
                    if(activityLesson.get(j).getLesson().equalsIgnoreCase(bookings.get(i).getLesson())){
                        System.out.println("\t\t\t\tClass On : "+activityLesson.get(j).getLessonDate());
                        System.out.println("\t\t\t\tClass Timings : "+activityLesson.get(j).getLessonAt());
                        System.out.println("\t\t\t\tClass Day : "+activityLesson.get(j).getWeekendDay());
                        System.out.println("\t\t\t\tClass Date : "+activityLesson.get(j).getLessonDate());
                    }
                }
                System.out.println("==================================================================================================");
                counter += 1;
            }else if(bookingsId == 0 && customerCode.equalsIgnoreCase("")){
                System.out.println("\nBookings Detail "+counter+" :- \n");
                System.out.println("\t\t\t\tBooking ID : "+bookings.get(i).getBookingID());
                System.out.println("\t\t\t\tActivity : "+bookings.get(i).getActivity());
                System.out.println("\t\t\t\tLesson : "+bookings.get(i).getLesson());
                System.out.println("\t\t\t\tCost : $"+bookings.get(i).getCost());
                System.out.println("\t\t\t\tBooked On : "+bookings.get(i).getBookingConfirmedAt());
                System.out.println("\t\t\t\tBooked By : "+bookings.get(i).getBookedBy());
                System.out.println("\t\t\t\tBooking Status : "+bookings.get(i).getBookingStatus());

                System.out.println("\nLesosn Detail :- \n");

                for(int j=0; j<activityLesson.size(); j++){
                    if(activityLesson.get(j).getLesson().equalsIgnoreCase(bookings.get(i).getLesson())){
                        System.out.println("\t\t\t\tClass On : "+activityLesson.get(j).getLessonDate());
                        System.out.println("\t\t\t\tClass Timings : "+activityLesson.get(j).getLessonAt());
                        System.out.println("\t\t\t\tClass Day : "+activityLesson.get(j).getWeekendDay());
                        System.out.println("\t\t\t\tClass Date : "+activityLesson.get(j).getLessonDate());
                    }
                }
                System.out.println("==================================================================================================");
                counter += 1;
            }
        }
        
        if(bookings.size() >=1){
            System.out.print("\nEnter 'Y' to apply filter on bookings : ");
            Scanner sc = new Scanner(System.in);
            String applyFilter =sc.nextLine();

            if(applyFilter.equalsIgnoreCase("Y") || applyFilter.equalsIgnoreCase("Yes")){
                filterOnBookings();
            }
        }

    }
    
    private static void filterOnBookings(){
        Scanner sc = new Scanner(System.in);

        System.out.println("\nSelect Option.  : ");
        System.out.println("1. Filter By Customer Code");
        System.out.println("2. Filter By Booking ID");
        System.out.print("\nPlease Enter your choice : ");

        String getOption = sc.nextLine();
        while (getOption.equals("") || !checkSelectOptionValidOrNot(getOption))
        {
            System.out.print("\nYou must enter a numerical menu option - ");
            getOption = sc.nextLine();
        }
        
        int givenChoice = Integer.parseInt(getOption);
        
        switch (givenChoice)
        {
            case 1 -> filterOnCustomerCode();
            case 2 -> filterOnBookingId();
            default -> System.out.println("\nPlease Enter Valid Option");
        }
    }
    
    
    private static void filterOnCustomerCode(){
        Scanner sc = new Scanner(System.in);
        System.out.print("\nEnter Customer Code : ");
        String customerCode = sc.nextLine();
        bookings(customerCode,0);
    }
    private static void filterOnBookingId(){
        Scanner sc = new Scanner(System.in);
        System.out.print("\nEnter Bookings ID : ");
        int bookingId = sc.nextInt();
        bookings("",bookingId);
    }
    
    private static void cancel(){
        Scanner sc = new Scanner(System.in);
        System.out.print("\nEnter Bookings ID : ");
        int bookingId = sc.nextInt();
        
        boolean isBookingExist = isBookingExist(bookingId);
        if(!isBookingExist){
            System.out.println("\nGiven Booking ID does not exist in the system");
            return;
        }
        
        List<Bookings> bookings = Bookings.getBookings();
        for(int i=0; i<bookings.size(); i++){
            if(bookings.get(i).getBookingID() == bookingId){
                bookings.get(i).setBookingStatus(Bookings.CANCELLED);
            }
        }
        System.out.println("\nYour Booking with booking ID "+bookingId+" has been cancelled");
    }
    
    
    private static boolean isBookingExist(int bookingId){
        boolean isBookingExist = false;
        
        List<Bookings> bookings = Bookings.getBookings();
        for(int i=0; i<bookings.size(); i++){
            if(bookings.get(i).getBookingID() == bookingId){
                isBookingExist = true;
            }
        }
        return isBookingExist;
    }
    
    
    private static void change(){
        Scanner sc = new Scanner(System.in);
        System.out.print("\nEnter Bookings ID : ");
        int bookingId = sc.nextInt();
        
        boolean isBookingExist = isBookingExist(bookingId);
        if(!isBookingExist){
            System.out.println("\nGiven Booking ID does not exist in the system");
            return;
        }
        
        List<ActivityLessons> activityLessons = ActivityLessons.activityLessons();
        System.out.println("\n-------------- Available Lessons as below -------------- \n");
        for(int i=0; i<activityLessons.size(); i++){
            System.out.println(activityLessons.get(i).getLesson());
        }
        
        Scanner sc1 = new Scanner(System.in);
        System.out.print("\nEnter any of the above lesson : ");
        String lesson = sc1.nextLine();
        
        
        if(!lesson.equalsIgnoreCase("")){
            boolean selectedLessonExists = selectedLessonExists(lesson);
            if(!selectedLessonExists){
                System.out.println("\n\nGiven lesson does not exist in the system");
                return;
            }

            //Get activity
            String activity = "";
            for(int i=0; i<activityLessons.size(); i++){
                if(activityLessons.get(i).getLesson().equalsIgnoreCase(lesson)){
                    activity = activityLessons.get(i).getActivity();
                }
            }

            //Change Bookings
            List<Bookings> bookings = Bookings.getBookings();
            for(int i=0; i<bookings.size(); i++){
                if(bookings.get(i).getBookingID() == bookingId){
                    bookings.get(i).setActivity(activity);
                    bookings.get(i).setLesson(lesson);
                    bookings.get(i).setBookingStatus(Bookings.CHANGED);
                }
            }
            
            System.out.println("\nYour Bookings details with booking id "+bookingId+" has been updated.");
        }
    }
    
    
    private static void classReview(){
        Scanner sc = new Scanner(System.in);
        System.out.print("\nEnter Bookings ID : ");
        int bookingId = sc.nextInt();
        
        boolean isBookingExist = isBookingExist(bookingId);
        if(!isBookingExist){
            System.out.println("\nGiven Booking ID does not exist in the system");
            return;
        }
        //Get lesson and activity
        String activity = "";
        String lesson = "";
        String reviewBy = "";
        List<Bookings> bookings= Bookings.getBookings();
        for(int i=0; i<bookings.size(); i++){
            if(bookings.get(i).getBookingID() == bookingId){
                activity = bookings.get(i).getActivity();
                lesson = bookings.get(i).getLesson();
                reviewBy = bookings.get(i).getBookedBy();
            }
        }
        
        Scanner sc1 = new Scanner(System.in);
        System.out.print("\nEnter your experience about the class : \n");
        String classExperiences = sc1.nextLine();
        
        int getRatingNumber = getRatingNumber();
    
        AllReviews obj = new AllReviews(activity,lesson,classExperiences,getRatingNumber,reviewBy);
        AllReviews.totalReviews.add(obj);
        
        for(int i=0; i<bookings.size(); i++){
            if(bookings.get(i).getBookingID() == bookingId){
               bookings.get(i).setBookingStatus(Bookings.ATTENDED);
            }
        }
        
        System.out.println("\nThanks for sharing your experience");
    }
    
    
    
    private static void getIncReport(){
        
        IncomeReportInstance report = IncomeReportInstance.getInstance();
        report.downloadAndPrintReport();
    }
    
    
    
    private static void getAvgRatingReport() throws IOException{
        
        try {
            fileWriter = new FileWriter("avgRatingReport.txt", false);
            bufferedWriter = new BufferedWriter(fileWriter);
            printWriter = new PrintWriter(bufferedWriter);
        
        
            System.out.println("\n\nDownload the Customer Totals Report for Each Course together with the Average Rating Report  ");
            printWriter.write("\n\nCustomer Totals Report for Each Course together with the Average Rating Report");

            Scanner getInp = new Scanner(System.in);
            System.out.print("\nEnter Month Number between (1-12) to download report for that month :");
            String monthOfReport = getInp.nextLine();

            List<Bookings> bookings = Bookings.getBookings();
            List<ActivityLessons> activityLessons = ActivityLessons.activityLessons();
            List<AllReviews> allreviews = AllReviews.getReviews();
            int countCustomers = 0;
            int countRatings = 0;
            int calAvgRate = 0;

            String activityLesson = "";
            String reviewLesson = "";
            System.out.println();
            for(int i=0; i<activityLessons.size(); i++){

                for(int j=0; j<bookings.size(); j++){

                    String bookingMonth = bookings.get(j).getBookingConfirmedAt();
                    DateTimeFormatter formattedDate = DateTimeFormatter.ofPattern("yyyy-MM-dd");  
                    LocalDate convertDate = LocalDate.parse(bookingMonth, formattedDate);
                    int bookingMonths = convertDate.getMonthValue();

                    if(activityLessons.get(i).getLesson().equalsIgnoreCase(bookings.get(j).getLesson()) 
                            && bookingMonths == Integer.parseInt(monthOfReport)){
                        countCustomers = countCustomers + 1;
                        activityLesson = bookings.get(j).getLesson();
                    }               
                }

                //Average Rating
                for(int k=0; k<allreviews.size(); k++){

                    if(activityLessons.get(i).getLesson().equalsIgnoreCase(allreviews.get(k).getLesson())){
                        countRatings = countRatings + 1;
                        calAvgRate = calAvgRate + allreviews.get(k).getRating();
                        reviewLesson = allreviews.get(k).getLesson();
                    }
                }

                if(!activityLessons.get(i).getLesson().equalsIgnoreCase(activityLesson)){
                    countCustomers = 0;
                }

                if(!activityLessons.get(i).getLesson().equalsIgnoreCase(reviewLesson)){
                    countRatings = 0;
                    calAvgRate = 0;
                }
                double findRatingsOfCustomer = 0.0;
                if(countRatings != 0){
                    findRatingsOfCustomer = calAvgRate/countRatings;
                }else{
                    findRatingsOfCustomer = 0;
                }
                System.out.println("\n[Lesson :- "+activityLessons.get(i).getLesson()+", Average Ratings By Customers :- "+findRatingsOfCustomer+", No. Of Customers :- "+countCustomers+"]");
                printWriter.write("\n[Lesson :- "+activityLessons.get(i).getLesson()+", Average Ratings By Customers :- "+findRatingsOfCustomer+", No. Of Customers :- "+countCustomers+"]");
            }
            System.out.println("\nReport is Downloaded in your project folder");
        }finally {
            try {
                printWriter.close();
                bufferedWriter.close();
                fileWriter.close();
            } catch (IOException io) {
            }
        }
    }
    
    
    private static int getRatingNumber(){
        Scanner sc = new Scanner(System.in);
        System.out.println("\nSelect Any Rating for the lesson : ");
        System.out.println("1. Very Dissatisfied");
        System.out.println("2. Dissatisfied");
        System.out.println("3. OK");
        System.out.println("4. Satisfied");
        System.out.println("5. Very Satisfied");
        
        System.out.print("\nEnter an Option : ");
        String choice = sc.nextLine();
        
        while (choice.equals("") || !checkSelectOptionValidOrNot(choice))
        {
            System.out.print("\nYou must enter a numerical menu option : ");
            choice = sc.nextLine();
        }
        
        if(Integer.parseInt(choice) < 0 || Integer.parseInt(choice) > 5){
            do{
                System.out.print("\nNot Valid Option : ");
                choice = sc.nextLine();
            }while(Integer.parseInt(choice) < 0 || Integer.parseInt(choice) > 2);
        }   
        return Integer.parseInt(choice);
    }
    
}
