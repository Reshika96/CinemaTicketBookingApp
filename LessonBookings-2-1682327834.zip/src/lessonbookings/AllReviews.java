
package lessonbookings;

import java.util.ArrayList;
import java.util.List;


public class AllReviews {
    
    private String activity;
    private String lesson;
    private String lessonExperience;
    private int rating;
    private String addedBy;

    public static ArrayList <AllReviews> totalReviews = new ArrayList<>();

    public AllReviews(String activity, String lesson, String lessonExperience, int rating, String addedBy) {
        this.activity = activity;
        this.lesson = lesson;
        this.lessonExperience = lessonExperience;
        this.rating = rating;
        this.addedBy = addedBy;
    }

    public String getActivity() {
        return activity;
    }

    public String getLesson() {
        return lesson;
    }

    public String getLessonExperience() {
        return lessonExperience;
    }

    public int getRating() {
        return rating;
    }

    public String getAddedBy() {
        return addedBy;
    }
    
    public static  List<AllReviews> getReviews(){
        return totalReviews;
    }
}
