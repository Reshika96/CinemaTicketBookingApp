
package lessonbookings;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;


public class IncomeReportInstance {
    private static IncomeReportInstance instance;
    private FileWriter fileWriter;
    private BufferedWriter bufferedWriter;
    private PrintWriter printWriter;
    
    private IncomeReportInstance() {
    }
    
    public static IncomeReportInstance getInstance() {
        if (instance == null) {
            instance = new IncomeReportInstance();
        }
        return instance;
    }

    public void downloadAndPrintReport() {
        try {
            fileWriter = new FileWriter("activityIncomeReport.txt", false);
            bufferedWriter = new BufferedWriter(fileWriter);
            printWriter = new PrintWriter(bufferedWriter);
            System.out.println("\n\nGet the Income Report produced for each activity -");
            printWriter.write("\n\nIncome Report produced for each activity -");
            List<Bookings> bookings = Bookings.getBookings();
            List<ActivityLessons> activityLessons = ActivityLessons.activityLessons();
            Map<String, Double> getReport = new HashMap<>();                                 


            Scanner getInp = new Scanner(System.in);
            System.out.print("\nEnter Month Number between (1-12) to download report :");
            String monthOfReport = getInp.nextLine();

            ArrayList<Bookings> copyBookingsList = new ArrayList<>();
            copyBookingsList.addAll(bookings);
            System.out.println();


            for(int i = 0; i < activityLessons.size(); i++) {
                String activity = null;
                double findTotalIncome = 0.0;
                for(int m = 0; m < copyBookingsList.size(); m++) {      

                    String bookingMonth = copyBookingsList.get(m).getBookingConfirmedAt();
                    DateTimeFormatter formatteddate = DateTimeFormatter.ofPattern("yyyy-MM-dd");  
                    LocalDate convertDate = LocalDate.parse(bookingMonth, formatteddate);
                    int bookingMonths = convertDate.getMonthValue();

                    if(activityLessons.get(i).getActivity().equalsIgnoreCase(copyBookingsList.get(m).getActivity()) 
                            && bookingMonths == Integer.parseInt(monthOfReport)
                            && copyBookingsList.get(m).getBookingStatus().equalsIgnoreCase(Bookings.ATTENDED)) {

                        findTotalIncome += activityLessons.get(i).getCost();
                        activity = copyBookingsList.get(m).getActivity();
                        copyBookingsList.remove(m); 
                        m--; 
                    }
                }

                if(activity != null) {
                    getReport.merge(activity, findTotalIncome, Double::sum);
                }            
            }
            getReport.forEach((act, generatedInc) -> {
                System.out.println(act+" :-\t\t $"+generatedInc);
                printWriter.write("\n"+act+" :-\t\t $"+generatedInc+"\n\n");
            });
            
            System.out.println("\nReport is Downloaded in your project folder");
        } catch (IOException io) {
            io.printStackTrace();
        } finally {
            try {
                if (printWriter != null) {
                    printWriter.close();
                }
                if (bufferedWriter != null) {
                    bufferedWriter.close();
                }
                if (fileWriter != null) {
                    fileWriter.close();
                }
            } catch (IOException io) {
                io.printStackTrace();
            }
        }
    }
}


