
package lessonbookings;

import java.util.ArrayList;
import java.util.List;


public class ActivityLessons {
    
    private String activity;
    private String lesson;
    private String weekendDay;
    private String lessonAt;
    private String lessonDate;
    private double cost;
    private String available;
    private int seats;

    public static ArrayList <ActivityLessons> activityLessons = new ArrayList<>();

    public ActivityLessons(String activity, String lesson, String weekendDay, String lessonAt, String lessonDate, double cost, String available, int seats) {
        this.activity = activity;
        this.lesson = lesson;
        this.weekendDay = weekendDay;
        this.lessonAt = lessonAt;
        this.lessonDate = lessonDate;
        this.cost = cost;
        this.available = available;
        this.seats = seats;
    }

    

    public String getActivity() {
        return activity;
    }

    public String getLesson() {
        return lesson;
    }

    public String getWeekendDay() {
        return weekendDay;
    }

    public String getLessonAt() {
        return lessonAt;
    }

    public double getCost() {
        return cost;
    }

    public String getAvailable() {
        return available;
    }

    public int getSeats() {
        return seats;
    }

    public String getLessonDate() {
        return lessonDate;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public void setAvailable(String available) {
        this.available = available;
    }
    
    
    
    public static  List<ActivityLessons> activityLessons(){
        activityLessons.removeAll(activityLessons);
        ActivityLessons aL1 = new ActivityLessons("Box Fit","Box Fit Title 1","Sun","09:10 to 11:10","05March,2023",40.45,"Available",5);
        ActivityLessons aL9 = new ActivityLessons("Zumba","Zumba Title 1","Sun","09:10 to 11:10","19March,2023",51.30,"Available",5);
        ActivityLessons aL17 = new ActivityLessons("Spin","Spin Title 1","Sun","09:10 to 11:10","02April,2023",47.20,"Available",5);
        ActivityLessons aL25 = new ActivityLessons("Bodysculpt","Bodysculpt Title 1","Sun","09:10 to 11:10","16April,2023",54.60,"Available",5);

        
        ActivityLessons aL2 = new ActivityLessons("Box Fit","Box Fit Title 2","Sat","09:10 to 11:10","04March,2023",40.45,"Available",5);
        ActivityLessons aL10 = new ActivityLessons("Zumba","Zumba Title 2","Sat","09:10 to 11:10","18March,2023",51.30,"Available",5);
        ActivityLessons aL18 = new ActivityLessons("Spin","Spin Title 2","Sat","09:10 to 11:10","01April,2023",47.20,"Available",5);
        ActivityLessons aL26 = new ActivityLessons("Bodysculpt","Bodysculpt Title 2","Sat","09:10 to 11:10","15April,2023",54.60,"Available",5);

                
                
        ActivityLessons aL3 = new ActivityLessons("Box Fit","Box Fit Title 3","Sun","11:30 to 13:30","05March,2023",40.45,"Available",5);
        ActivityLessons aL11 = new ActivityLessons("Zumba","Zumba Title 3","Sun","11:30 to 13:30","19March,2023",51.30,"Available",5);
        ActivityLessons aL19 = new ActivityLessons("Spin","Spin Title 3","Sun","11:30 to 13:30","02April,2023",47.20,"Available",5);
        ActivityLessons aL27 = new ActivityLessons("Bodysculpt","Bodysculpt Title 3","Sun","11:30 to 13:30","16April,2023",54.60,"Available",5);

        
        
        
        
        ActivityLessons aL4 = new ActivityLessons("Box Fit","Box Fit Title 4","Sat","11:30 to 13:30","04March,2023",40.45,"Available",5);
        ActivityLessons aL12 = new ActivityLessons("Zumba","Zumba Title 4","Sat","11:30 to 13:30","18March,2023",51.30,"Available",5);
        ActivityLessons aL20 = new ActivityLessons("Spin","Spin Title 4","Sat","11:30 to 13:30","01April,2023",47.20,"Available",5);
        ActivityLessons aL28 = new ActivityLessons("Bodysculpt","Bodysculpt Title 4","Sat","11:30 to 13:30","15April,2023",54.60,"Available",5);

        
        
        ActivityLessons aL5 = new ActivityLessons("Box Fit","Box Fit Title 5","Sun","09:10 to 11:10","12March,2023",40.45,"Available",5);
        ActivityLessons aL13 = new ActivityLessons("Zumba","Zumba Title 5","Sun","09:10 to 11:10","26March,2023",51.30,"Available",5);
        ActivityLessons aL21 = new ActivityLessons("Spin","Spin Title 5","Sun","09:10 to 11:10","09April,2023",47.20,"Available",5);
        ActivityLessons aL29 = new ActivityLessons("Bodysculpt","Bodysculpt Title 5","Sun","09:10 to 11:10","23April,2023",54.60,"Available",5);

        
        
        
        
        ActivityLessons aL6 = new ActivityLessons("Box Fit","Box Fit Title 6","Sat","09:10 to 11:10","11March,2023",40.45,"Available",5);
        ActivityLessons aL14 = new ActivityLessons("Zumba","Zumba Title 6","Sat","09:10 to 11:10","25March,2023",51.30,"Available",5);
        ActivityLessons aL22 = new ActivityLessons("Spin","Spin Title 6","Sat","09:10 to 11:10","08April,2023",47.20,"Available",5);
        ActivityLessons aL30 = new ActivityLessons("Bodysculpt","Bodysculpt Title 6","Sat","09:10 to 11:10","22April,2023",54.60,"Available",5);

        
        
        ActivityLessons aL7 = new ActivityLessons("Box Fit","Box Fit Title 7","Sun","11:30 to 13:30","12March,2023",40.45,"Available",5);
        ActivityLessons aL15 = new ActivityLessons("Zumba","Zumba Title 7","Sun","11:30 to 13:30","26March,2023",51.30,"Available",5);
        ActivityLessons aL23 = new ActivityLessons("Spin","Spin Title 7","Sun","11:30 to 13:30","09April,2023",47.20,"Available",5);
        ActivityLessons aL31 = new ActivityLessons("Bodysculpt","Bodysculpt Title 7","Sun","11:30 to 13:30","23April,2023",54.60,"Available",5);
        
        
        ActivityLessons aL8 = new ActivityLessons("Box Fit","Box Fit Title 8","Sat","11:30 to 13:30","11March,2023",40.45,"Available",5);
        ActivityLessons aL16 = new ActivityLessons("Zumba","Zumba Title 8","Sat","11:30 to 13:30","25March,2023",51.30,"Available",5);
        ActivityLessons aL24 = new ActivityLessons("Spin","Spin Title 8","Sat","11:30 to 13:30","08April,2023",47.20,"Available",5);
        ActivityLessons aL32 = new ActivityLessons("Bodysculpt","Bodysculpt Title 8","Sat","11:30 to 13:30","22April,2023",54.60,"Available",5);
       
        
        ActivityLessons.activityLessons.add(aL1);
        ActivityLessons.activityLessons.add(aL9);
        ActivityLessons.activityLessons.add(aL17);
        ActivityLessons.activityLessons.add(aL25);

        
        
        ActivityLessons.activityLessons.add(aL2);
        ActivityLessons.activityLessons.add(aL10);
        ActivityLessons.activityLessons.add(aL18);
        ActivityLessons.activityLessons.add(aL26);


        
        
        
        
        ActivityLessons.activityLessons.add(aL3);
        ActivityLessons.activityLessons.add(aL11);
        ActivityLessons.activityLessons.add(aL19);
        ActivityLessons.activityLessons.add(aL27);

        
        
        
        ActivityLessons.activityLessons.add(aL4);
        ActivityLessons.activityLessons.add(aL12);
        ActivityLessons.activityLessons.add(aL20);
        ActivityLessons.activityLessons.add(aL28);

        
        
        
        ActivityLessons.activityLessons.add(aL5);
        ActivityLessons.activityLessons.add(aL13);
        ActivityLessons.activityLessons.add(aL21);
        ActivityLessons.activityLessons.add(aL29);

        
        
        ActivityLessons.activityLessons.add(aL6);
        ActivityLessons.activityLessons.add(aL14);
        ActivityLessons.activityLessons.add(aL22);
        ActivityLessons.activityLessons.add(aL30);

        
        
        
        ActivityLessons.activityLessons.add(aL7);
        ActivityLessons.activityLessons.add(aL15);
        ActivityLessons.activityLessons.add(aL23);
        ActivityLessons.activityLessons.add(aL31);

        
        
        ActivityLessons.activityLessons.add(aL8);
        ActivityLessons.activityLessons.add(aL16);
        ActivityLessons.activityLessons.add(aL24);
        ActivityLessons.activityLessons.add(aL32);
        
        return activityLessons;
    }
    
    
    
}
