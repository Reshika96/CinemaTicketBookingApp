
package lessonbookings;

import java.util.ArrayList;
import java.util.List;


public class Bookings {
    
    private int bookingID;
    private String activity;
    private String lesson;
    private double cost;
    private String bookingConfirmedAt;
    private String bookedBy;
    private String bookingStatus;
    
    public static ArrayList <Bookings> totalBookings = new ArrayList<>();

    public static final String BOOKED = "Booked";
    public static final String ATTENDED = "Attended";
    public static final String CHANGED = "Changed";
    public static final String CANCELLED = "Cancelled";
    public static final int TOTAL_SEATS = 5;

    public Bookings(int bookingID, String activity, String lesson, String bookingConfirmedAt, String bookedBy, String bookingStatus,double cost) {
        this.bookingID = bookingID;
        this.activity = activity;
        this.lesson = lesson;
        this.bookingConfirmedAt = bookingConfirmedAt;
        this.bookedBy = bookedBy;
        this.bookingStatus = bookingStatus;
        this.cost = cost;
    }

    public int getBookingID() {
        return bookingID;
    }

    public String getActivity() {
        return activity;
    }

    public String getLesson() {
        return lesson;
    }

    public String getBookingConfirmedAt() {
        return bookingConfirmedAt;
    }

    public String getBookedBy() {
        return bookedBy;
    }

    public double getCost() {
        return cost;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public void setLesson(String lesson) {
        this.lesson = lesson;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    
    public static  List<Bookings> getBookings(){
        return totalBookings;
    }
}
